  let contador = 0;
  let parada = "stop";

  //loop usando WHILE
  while (contador <10){
    console.log('Loop While' - $ {contador});
    contador++;
}

ddo{
    console.log('Loop Do - ${contador}')
    contador++
}while(contador<10);
